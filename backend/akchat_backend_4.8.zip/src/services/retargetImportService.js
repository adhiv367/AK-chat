// Retarget module — import service.
// Shared logic for CSV/Excel file import AND Google Sheet sync:
//   - parse a workbook buffer into a grid
//   - auto-detect Name/Phone/Email/ExitURL/RetargetType/Timestamp columns
//   - auto-detect retarget_type (cart_abandonment / checkout_exit / page_exit
//     / other) from the exit URL when the sheet doesn't provide one
//   - upsert into coexistence.retarget_customers by phone number
//
// Mirrors the conventions of services/contactSyncService.js and
// routes/contacts.js's Excel/CSV import block, so behaviour stays
// consistent with the rest of the app.

const ExcelJS = require('exceljs');
const { Readable } = require('stream');
const pool = require('../db');
const retargetRepository = require('../repositories/retargetRepository');
const { detectRetargetType, detectExitCategory } = require('./retargetClassifier');
// Contacts bridge — every Retarget customer created/updated is mirrored into
// coexistence.contacts (Contacts <-> Retarget integration). Reuses the same
// upsert helper that Google Sheet sync / Shopify sync already rely on, so
// there's exactly one place that knows how to write a Retarget customer
// into Contacts.
const { upsertContactFromRetarget } = require('./contactSyncService');

// Exact-match phone lookup. retargetRepository.findAll() only supports
// ILIKE substring search, which isn't safe for dedupe (e.g. phone "919000012"
// would match "9190000123"), so import/sync upserts query directly here.
async function findByPhone(phone) {
  const { rows } = await pool.query(
    `SELECT id, name, phone, email, exit_url, retarget_type, timestamp, source, status
       FROM coexistence.retarget_customers WHERE phone = $1 LIMIT 1`,
    [phone]
  );
  return rows[0] || null;
}

// ── Phone normalization (same rules as contactSyncService.normalizePhone) ──
function normalizePhone(raw) {
  if (!raw) return null;
  let digits = String(raw).replace(/\D/g, '');
  digits = digits.replace(/^0+/, '');
  if (!digits) return null;
  if (digits.length === 10) digits = '91' + digits; // default India country code
  if (digits.length < 11 || digits.length > 15) return null;
  return digits;
}

// ── Header detection (accepts many aliases, same spirit as
// routes/contacts.js IMPORT_HEADER_MAP / googleSheetService HEADER_MAP) ────
const HEADER_MAP = {
  name: 'name', 'customer name': 'name', 'full name': 'name', client: 'name', customer: 'name',
  phone: 'phone', mobile: 'phone', 'phone number': 'phone', 'mobile number': 'phone',
  'contact number': 'phone', 'contact no': 'phone', 'mobile no': 'phone', whatsapp: 'phone',
  'whatsapp number': 'phone', msisdn: 'phone',
  email: 'email', 'email address': 'email', mail: 'email',
  'exit url': 'exitUrl', exiturl: 'exitUrl', url: 'exitUrl', link: 'exitUrl', page: 'exitUrl', 'page url': 'exitUrl',
  'retarget type': 'retargetType', retargettype: 'retargetType', type: 'retargetType', category: 'retargetType',
  timestamp: 'timestamp', date: 'timestamp', 'exit date': 'timestamp', 'event time': 'timestamp', time: 'timestamp',
  source: 'source',
};

function normalizeHeaderKey(h) {
  return String(h || '').trim().toLowerCase();
}

function buildHeaderIndex(headerRow) {
  const index = {};
  headerRow.forEach((h, i) => {
    const mapped = HEADER_MAP[normalizeHeaderKey(h)];
    if (mapped && index[mapped] === undefined) index[mapped] = i;
  });
  return index;
}

function cellToString(cell) {
  if (cell == null) return '';
  if (cell instanceof Date) return cell.toISOString();
  if (typeof cell === 'object' && 'text' in cell) return String(cell.text);
  if (typeof cell === 'object' && 'result' in cell) return String(cell.result);
  return String(cell);
}

// Parses a CSV or XLSX buffer into a raw grid (array of arrays of strings).
async function parseWorkbookRows(buffer, filename = '') {
  const workbook = new ExcelJS.Workbook();
  if (filename.toLowerCase().endsWith('.csv')) {
    await workbook.csv.read(Readable.from(buffer));
  } else {
    await workbook.xlsx.load(buffer);
  }
  const ws = workbook.worksheets[0];
  if (!ws) return [];

  const grid = [];
  ws.eachRow({ includeEmpty: false }, (row) => {
    grid.push(row.values.slice(1).map(cellToString));
  });
  return grid;
}

// Turns a raw grid into normalized row objects using the detected header index.
function gridToRows(grid) {
  if (grid.length < 2) return { rows: [], headerIndex: {} };
  const headerIndex = buildHeaderIndex(grid[0]);
  const get = (row, key) => (headerIndex[key] !== undefined ? (row[headerIndex[key]] ?? '').toString().trim() : '');

  const rows = grid.slice(1).map((row) => ({
    name: get(row, 'name'),
    phone: get(row, 'phone'),
    email: get(row, 'email'),
    exitUrl: get(row, 'exitUrl'),
    retargetType: get(row, 'retargetType'),
    timestamp: get(row, 'timestamp'),
    source: get(row, 'source'),
  }));

  return { rows, headerIndex };
}

function parseTimestamp(raw) {
  if (!raw) return null;
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

/**
 * Upserts one normalized row into coexistence.retarget_customers by phone.
 * - No phone -> skipped
 * - Existing phone -> update (name/email/exitUrl/type/timestamp refreshed
 *   only when the incoming value is non-empty, so a sparse re-sync never
 *   blanks out previously-known data)
 * - New phone -> create
 * @returns {Promise<{created?:boolean, updated?:boolean, skipped?:boolean, reason?:string}>}
 */
async function upsertRetargetRow(row, defaultSource = 'import') {
  const phone = normalizePhone(row.phone);
  if (!phone) return { skipped: true, reason: 'missing/invalid phone number' };

  const exitUrl = row.exitUrl?.trim() || null;
  const retargetType = row.retargetType?.trim() || detectRetargetType(exitUrl);
  const timestamp = parseTimestamp(row.timestamp);
  const source = row.source?.trim() || defaultSource;

  const existing = await findByPhone(phone);

  if (existing) {
    const updated = await retargetRepository.update(existing.id, {
      name: row.name?.trim() || existing.name,
      email: row.email?.trim() || existing.email,
      exitUrl: exitUrl || existing.exit_url,
      retargetType: retargetType || existing.retarget_type,
      timestamp: timestamp || existing.timestamp,
      source,
    });
    await syncContactSafely(updated);
    return { updated: true, record: updated };
  }

  const created = await retargetRepository.create({
    name: row.name?.trim() || null,
    phone,
    email: row.email?.trim() || null,
    exitUrl,
    retargetType,
    timestamp,
    source,
    status: 'pending',
  });
  await syncContactSafely(created);
  return { created: true, record: created };
}

// Mirrors a Retarget customer into Contacts. Never throws — a Contacts sync
// hiccup (e.g. no WhatsApp account connected yet) must not fail the
// Retarget import/sync run itself; it's logged and skipped instead.
async function syncContactSafely(retargetCustomer) {
  try {
    await upsertContactFromRetarget(retargetCustomer);
  } catch (err) {
    console.error('[retarget] contact sync error:', err.message);
  }
}

/**
 * Imports every row from a parsed grid. Returns full run statistics used by
 * both the CSV/Excel import endpoint and the Google Sheet sync tick, so
 * Sync History can display them uniformly.
 * @returns {Promise<{total:number, imported:number, updated:number, skipped:number, errors:Array}>}
 */
async function importRows(rows, defaultSource = 'import') {
  let imported = 0, updated = 0, skipped = 0;
  const errors = [];

  for (const row of rows) {
    try {
      const result = await upsertRetargetRow(row, defaultSource);
      if (result.created) imported++;
      else if (result.updated) updated++;
      else if (result.skipped) skipped++;
    } catch (err) {
      errors.push({ row: row.phone || row.name || '(unknown)', reason: err.message });
    }
  }

  return { total: rows.length, imported, updated, skipped, errors };
}

// Full pipeline for a CSV/Excel upload buffer.
async function importFromBuffer(buffer, filename, defaultSource) {
  const grid = await parseWorkbookRows(buffer, filename);
  if (grid.length < 2) {
    const err = new Error('File is empty or has no data rows');
    err.status = 400;
    throw err;
  }
  const { rows, headerIndex } = gridToRows(grid);
  if (headerIndex.phone === undefined) {
    const err = new Error('Could not find a Phone column in this file');
    err.status = 400;
    throw err;
  }
  return importRows(rows, defaultSource || (filename.toLowerCase().endsWith('.csv') ? 'csv_import' : 'excel_import'));
}

module.exports = {
  normalizePhone,
  detectRetargetType,
  detectExitCategory,
  parseWorkbookRows,
  gridToRows,
  buildHeaderIndex,
  upsertRetargetRow,
  importRows,
  importFromBuffer,
};
