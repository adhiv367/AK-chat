const API_VERSION = process.env.META_API_VERSION || 'v21.0';

function getAuthUrl(state) {
  const scopes = [
    'instagram_basic',
    'instagram_manage_messages',
    'pages_show_list',
    'pages_read_engagement',
    'pages_manage_metadata',
    'business_management',
  ].join(',');
  const redirect = process.env.META_IG_REDIRECT_URI;
  return `https://www.facebook.com/${API_VERSION}/dialog/oauth?client_id=${process.env.META_IG_APP_ID}&redirect_uri=${encodeURIComponent(redirect)}&scope=${scopes}&state=${state}&response_type=code`;
}

async function exchangeCodeForToken(code) {
  const url = `https://graph.facebook.com/${API_VERSION}/oauth/access_token?client_id=${process.env.META_IG_APP_ID}&client_secret=${process.env.META_IG_APP_SECRET}&redirect_uri=${encodeURIComponent(process.env.META_IG_REDIRECT_URI)}&code=${code}`;
  const resp = await fetch(url);
  const data = await resp.json();
  if (!resp.ok) throw new Error(data?.error?.message || 'Token exchange failed');
  return data.access_token;
}

async function getLongLivedToken(shortToken) {
  const url = `https://graph.facebook.com/${API_VERSION}/oauth/access_token?grant_type=fb_exchange_token&client_id=${process.env.META_IG_APP_ID}&client_secret=${process.env.META_IG_APP_SECRET}&fb_exchange_token=${shortToken}`;
  const resp = await fetch(url);
  const data = await resp.json();
  if (!resp.ok) throw new Error(data?.error?.message || 'Long-lived token exchange failed');
  return data; // { access_token, expires_in }
}

async function getPages(userToken) {
  const url = `https://graph.facebook.com/${API_VERSION}/me/accounts?fields=id,name,access_token,instagram_business_account&access_token=${userToken}`;
  const resp = await fetch(url);
  const data = await resp.json();
  if (!resp.ok) throw new Error(data?.error?.message || 'Failed to list pages');
  return data.data || [];
}

async function getInstagramProfile(igBusinessId, pageAccessToken) {
  const url = `https://graph.facebook.com/${API_VERSION}/${igBusinessId}?fields=username,profile_picture_url,name&access_token=${pageAccessToken}`;
  const resp = await fetch(url);
  const data = await resp.json();
  if (!resp.ok) throw new Error(data?.error?.message || 'Failed to fetch IG profile');
  return data;
}

module.exports = { getAuthUrl, exchangeCodeForToken, getLongLivedToken, getPages, getInstagramProfile };

