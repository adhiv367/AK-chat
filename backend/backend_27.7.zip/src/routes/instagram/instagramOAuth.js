const express = require("express");
const crypto = require("crypto");

const {
  getAuthUrl,
  exchangeCodeForToken,
  getLongLivedToken,
  getPages,
  getInstagramProfile,
} = require("../../services/instagramOAuthService");

const {
  upsertAccount,
} = require("../../services/instagramAccountService");

const router = express.Router();

/**
 * GET /api/instagram/oauth/start
 */
router.get("/start", (req, res) => {
  try {
    const state = crypto.randomBytes(16).toString("hex");
    const url = getAuthUrl(state);

    return res.redirect(url);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

/**
 * GET /api/instagram/oauth/callback
 */
router.get("/callback", async (req, res) => {
  try {
    const { code } = req.query;

    if (!code) {
      return res.status(400).json({
        success: false,
        error: "Missing authorization code",
      });
    }

    // Exchange code
    const shortToken = await exchangeCodeForToken(code);

    // Long lived token
    const tokenInfo = await getLongLivedToken(shortToken);

    const accessToken = tokenInfo.access_token;
    const expiresAt = new Date(
      Date.now() + (tokenInfo.expires_in || 0) * 1000
    );

    // Get Facebook Pages
    const pages = await getPages(accessToken);

    for (const page of pages) {
      if (!page.instagram_business_account) continue;

      const profile = await getInstagramProfile(
        page.instagram_business_account.id,
        page.access_token
      );

      await upsertAccount({
        accountName: profile.username,
        igBusinessId: page.instagram_business_account.id,
        pageId: page.id,
        username: profile.username,
        pageName: page.name,
        accessToken: page.access_token,
        expiresAt,
        profilePicture: profile.profile_picture_url || null,
      });
    }

    return res.redirect("http://localhost:3000/#/ig-accounts");
  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

module.exports = router;




