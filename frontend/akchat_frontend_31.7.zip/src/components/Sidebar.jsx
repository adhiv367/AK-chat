import { useState } from 'react';
import {
  Home, Zap, LayoutTemplate, MessageCircle, Users,
  Megaphone, Image as ImageIcon, KanbanSquare, Target,
  ChevronLeft, ChevronRight, Settings,
} from 'lucide-react';
import { C, FONT } from '../constants.js';

const NAV_GROUPS = [
  {
    label: 'Workspace',
    items: [
      { id: 'home', label: 'Home', Icon: Home },
      { id: 'chats', label: 'Chats', Icon: MessageCircle },
      { id: 'contacts', label: 'Contacts', Icon: Users },
      { id: 'pipelines', label: 'Pipelines', Icon: KanbanSquare },
    ],
  },
  {
    label: 'Automate',
    items: [
      { id: 'chatbot-builder', label: 'Automations', Icon: Zap },
      { id: 'template-builder', label: 'Template Builder', Icon: LayoutTemplate },
      { id: 'bulk-message', label: 'Bulk Message', Icon: Megaphone },
      { id: 'target-message', label: 'Target Message', Icon: Target },
    ],
  },
  {
    label: 'Library',
    items: [
      { id: 'media-library', label: 'Media', Icon: ImageIcon },
    ],
  },
];

export default function Sidebar({ activePage, onPageChange, collapsed, setCollapsed, user }) {
  const [hoveredId, setHoveredId] = useState(null);

  const canSee = (id) => user?.role === 'admin' || !Array.isArray(user?.pages) || user.pages.includes(id);

  return (
    <div style={{
      width: collapsed ? 68 : 240,
      minHeight: '100%',
      background: C.navBg,
      borderRight: `1px solid ${C.navBorder}`,
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      transition: 'width .28s cubic-bezier(.4,0,.2,1)',
      overflow: 'hidden',
      position: 'relative',
    }}>
      {/* Nav groups */}
      <div style={{ padding: collapsed ? '16px 10px' : '20px 14px', flex: 1, overflowY: 'auto' }}>
        {NAV_GROUPS.map((group, gi) => {
          const visible = group.items.filter(item => canSee(item.id));
          if (visible.length === 0) return null;
          return (
            <div key={group.label} style={{ marginBottom: gi < NAV_GROUPS.length - 1 ? 22 : 0 }}>
              {!collapsed && (
                <div style={{
                  fontSize: 10.5,
                  fontWeight: 700,
                  letterSpacing: '.09em',
                  textTransform: 'uppercase',
                  color: C.navMuted,
                  padding: '0 10px 8px',
                  fontFamily: FONT,
                  opacity: .75,
                }}>
                  {group.label}
                </div>
              )}
              {visible.map(item => {
                const active = activePage === item.id;
                const hovered = hoveredId === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => onPageChange(item.id)}
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    title={collapsed ? item.label : ''}
                    style={{
                      position: 'relative',
                      display: 'flex',
                      alignItems: 'center',
                      gap: collapsed ? 0 : 11,
                      padding: collapsed ? '11px 0' : '10px 12px',
                      borderRadius: C.radiusMd,
                      cursor: 'pointer',
                      marginBottom: 3,
                      background: active ? C.navActiveBg : (hovered ? C.navHover : 'transparent'),
                      color: active ? C.navActiveText : C.navMuted,
                      justifyContent: collapsed ? 'center' : 'flex-start',
                      fontFamily: FONT,
                      fontSize: 13.5,
                      fontWeight: active ? 600 : 500,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      userSelect: 'none',
                      transition: 'background .15s ease, color .15s ease, transform .15s ease',
                      transform: hovered && !active ? 'translateX(2px)' : 'translateX(0)',
                    }}
                  >
                    {active && (
                      <span style={{
                        position: 'absolute',
                        left: 0,
                        top: 8,
                        bottom: 8,
                        width: 3,
                        borderRadius: 3,
                        background: C.navActiveBar,
                      }} />
                    )}
                    <span style={{
                      width: 18,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      color: active ? C.navActiveText : C.navMuted,
                    }}>
                      <item.Icon size={17} strokeWidth={active ? 2.25 : 2} />
                    </span>
                    {!collapsed && <span style={{ letterSpacing: '-.01em' }}>{item.label}</span>}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* User profile + collapse control */}
      <div style={{ borderTop: `1px solid ${C.navBorder}` }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: collapsed ? '12px 0' : '12px 14px',
          justifyContent: collapsed ? 'center' : 'flex-start',
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: C.radiusSm, flexShrink: 0,
            background: `linear-gradient(135deg, ${C.primary}, #9B7BEA)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 13, fontWeight: 700, color: '#fff', fontFamily: FONT,
          }}>
            {(user?.displayName || user?.username || 'U').charAt(0).toUpperCase()}
          </div>
          {!collapsed && (
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{
                fontSize: 12.5, fontWeight: 600, color: C.navText, fontFamily: FONT,
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
              }}>
                {user?.displayName || user?.username || 'User'}
              </div>
              <div style={{ fontSize: 11, color: C.navMuted, fontFamily: FONT }}>
                {user?.role === 'admin' ? 'Admin' : 'Member'}
              </div>
            </div>
          )}
        </div>

        <div
          onClick={() => setCollapsed(p => !p)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: collapsed ? '12px 0' : '11px 14px',
            cursor: 'pointer',
            justifyContent: collapsed ? 'center' : 'flex-start',
            transition: 'background .15s',
            color: C.navMuted,
            borderTop: `1px solid ${C.navBorder}`,
          }}
          onMouseEnter={e => e.currentTarget.style.background = C.navHover}
          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <span style={{
            width: 22, height: 22, borderRadius: 7,
            background: C.navHover,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            {collapsed ? <ChevronRight size={13} /> : <ChevronLeft size={13} />}
          </span>
          {!collapsed && (
            <span style={{ fontSize: 12, fontWeight: 600, fontFamily: FONT }}>
              Collapse
            </span>
          )}
        </div>

        <div style={{ padding: collapsed ? '0 0 12px' : '0 14px 14px', textAlign: collapsed ? 'center' : 'left' }}>
          <span style={{
            fontSize: collapsed ? 7 : 9,
            fontWeight: 700,
            color: 'rgba(255,255,255,.22)',
            fontFamily: FONT,
            letterSpacing: '.08em',
            textTransform: 'uppercase',
          }}>
            {collapsed ? 'AK' : 'Powered by AK'}
          </span>
        </div>
      </div>
    </div>
  );
}




