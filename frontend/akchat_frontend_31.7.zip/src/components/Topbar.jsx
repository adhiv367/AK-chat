import { useState, useRef, useEffect } from 'react';
import { LogOut, Settings, AlertTriangle, Search, Bell } from 'lucide-react';
import { C, FONT } from '../constants.js';
import { api } from '../api.js';
import ModuleSwitch from './instagram/ModuleSwitch.jsx';

export default function Topbar({ user, onLogout, onNavigate, activeModule, onModuleChange }) {
  const [userOpen, setUserOpen] = useState(false);
  const [unhealthyAccounts, setUnhealthyAccounts] = useState([]);
  const [searchFocused, setSearchFocused] = useState(false);

  const ref = useRef(null);

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setUserOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const check = () => {
      api.whatsappAccounts.list()
        .then(accs => { if (!cancelled) setUnhealthyAccounts(accs.filter(a => a.healthStatus === 'invalid_token')); })
        .catch(() => {});
    };
    check();
    const t = setInterval(check, 60000);
    return () => { cancelled = true; clearInterval(t); };
  }, []);

  return (
    <>
    {unhealthyAccounts.length > 0 && (
      <div
        onClick={() => onNavigate('admin-settings')}
        style={{
          background: '#7C2D12', color: '#fff', padding: '8px 16px',
          fontSize: 12, fontFamily: FONT, display: 'flex', alignItems: 'center',
          justifyContent: 'center', gap: 8, cursor: 'pointer', fontWeight: 500,
        }}
      >
        <AlertTriangle size={14} />
        <span>
          Access token expired for {unhealthyAccounts.map(a => a.displayName).join(', ')} — click to update in Settings → WhatsApp Accounts
        </span>
      </div>
    )}
    <div style={{
      height: 64,
      background: C.headerBg,
      display: 'flex',
      alignItems: 'center',
      paddingLeft: 0,
      paddingRight: 24,
      borderBottom: `1px solid ${C.headerBorder}`,
      flexShrink: 0,
      zIndex: 100,
      position: 'relative',
      gap: 20,
    }}>
      {/* Logo area — aligns with sidebar */}
      <button
        onClick={() => onNavigate('chats')}
        style={{
          width: 240,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          paddingLeft: 20,
          gap: 9,
          borderRight: `1px solid ${C.headerBorder}`,
          height: '100%',
          background: 'transparent',
          border: 'none',
          borderRightWidth: 1,
          borderRightStyle: 'solid',
          cursor: 'pointer',
          textAlign: 'left',
        }}
      >
        <img
          src="/akchat-logo.gif"
          alt="AK Chat"
          style={{ height: 34, width: 34, objectFit: 'contain', flexShrink: 0, borderRadius: 9 }}
          onError={e => { e.currentTarget.style.display = 'none'; }}
        />
        <div style={{ lineHeight: 1.1 }}>
          <div style={{
            fontSize: 15.5,
            fontWeight: 800,
            color: C.headerText,
            fontFamily: FONT,
            letterSpacing: '-0.01em',
            lineHeight: 1,
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
          }}>
            AK
            <span style={{
              background: C.primary,
              color: '#fff',
              padding: '2.5px 8px',
              borderRadius: 7,
              lineHeight: 1.3,
              display: 'inline-block',
              fontSize: 13,
            }}>CHAT</span>
          </div>
        </div>
      </button>

      {/* Search bar */}
      <div style={{
        flex: 1,
        maxWidth: 440,
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        background: C.headerSurface,
        border: `1.5px solid ${searchFocused ? C.primary : C.border}`,
        borderRadius: C.radiusMd,
        padding: '9px 14px',
        color: C.textMuted,
        transition: 'border-color .15s',
      }}>
        <Search size={16} strokeWidth={2} color={searchFocused ? C.primary : C.textMuted} />
        <input
          onFocus={() => setSearchFocused(true)}
          onBlur={() => setSearchFocused(false)}
          placeholder="Search chats, contacts, templates…"
          style={{
            flex: 1,
            border: 'none',
            outline: 'none',
            background: 'transparent',
            fontSize: 13.5,
            fontFamily: FONT,
            color: C.text,
          }}
        />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <ModuleSwitch activeModule={activeModule} onModuleChange={onModuleChange} />
      </div>

      {/* Right controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginLeft: 'auto' }}>
        <button
          style={{
            width: 38, height: 38, borderRadius: C.radiusMd,
            border: `1px solid ${C.border}`, background: 'transparent',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', color: C.textSecondary,
            transition: 'background .15s, border-color .15s',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = C.primaryLight; e.currentTarget.style.borderColor = C.primary; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = C.border; }}
          title="Notifications"
        >
          <Bell size={17} />
        </button>

        {/* User avatar */}
        <div ref={ref} style={{ position: 'relative' }}>
          <button
            onClick={() => setUserOpen(p => !p)}
            style={{
              width: 38,
              height: 38,
              borderRadius: C.radiusMd,
              background: `linear-gradient(135deg, ${C.primary}, #9B7BEA)`,
              border: userOpen ? `2px solid ${C.primary}` : `1.5px solid ${C.border}`,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 15,
              fontWeight: 700,
              color: '#fff',
              fontFamily: FONT,
              transition: 'border .15s',
              padding: 0,
              overflow: 'hidden',
              marginLeft: 4,
            }}
          >
            {(user.displayName || user.username).charAt(0).toUpperCase()}
          </button>

          {userOpen && (
            <div style={{
              position: 'absolute',
              top: 48,
              right: 0,
              background: C.cardBg,
              border: `1px solid ${C.border}`,
              borderRadius: C.radiusMd,
              boxShadow: C.shadowMd,
              padding: 8,
              minWidth: 190,
              zIndex: 200,
            }}>
              <div style={{ padding: '9px 12px', borderBottom: `1px solid ${C.border}`, marginBottom: 5 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>
                  {user.displayName || user.username}
                </div>
                <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>
                  Owner
                </div>
              </div>
              <button
                onClick={() => { setUserOpen(false); onNavigate('admin-settings'); }}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '9px 12px',
                  borderRadius: C.radiusSm,
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: C.text,
                  fontSize: 13,
                  fontWeight: 600,
                  fontFamily: FONT,
                  marginBottom: 4,
                }}
              >
                <Settings size={14} />
                Settings
              </button>
              <button
                onClick={() => { setUserOpen(false); onLogout(); }}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '9px 12px',
                  borderRadius: C.radiusSm,
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: C.primary,
                  fontSize: 13,
                  fontWeight: 600,
                  fontFamily: FONT,
                }}
              >
                <LogOut size={14} />
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
    </>
  );
}