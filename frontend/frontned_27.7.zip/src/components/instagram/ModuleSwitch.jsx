import { FONT } from '../../constants.js';

export default function ModuleSwitch({ activeModule, onModuleChange }) {
  const options = [
    { id: 'whatsapp', label: 'WhatsApp' },
    { id: 'instagram', label: 'Instagram' },
  ];

  return (
    <div style={{
      display: 'flex',
      background: '#1a1a1a',
      borderRadius: 10,
      padding: 3,
      gap: 2,
    }}>
      {options.map(opt => {
        const active = activeModule === opt.id;
        return (
          <button
            key={opt.id}
            onClick={() => onModuleChange(opt.id)}
            style={{
              padding: '6px 18px',
              borderRadius: 8,
              border: 'none',
              cursor: 'pointer',
              fontFamily: FONT,
              fontSize: 13,
              fontWeight: 700,
              background: active
                ? (opt.id === 'instagram'
                    ? 'linear-gradient(135deg, #833AB4, #E1306C, #FCAF45)'
                    : '#dc2626')
                : 'transparent',
              color: active ? '#fff' : '#aaa',
              transition: 'all .15s',
            }}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}