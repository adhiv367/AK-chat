import { useState } from 'react';
import {
  Home, Zap, LayoutTemplate, MessageCircle, Users,
  Megaphone, Image as ImageIcon, KanbanSquare, Target,
  ChevronLeft, ChevronRight,
} from 'lucide-react';
import { C, FONT } from '../constants.js';

// Grouped like Roboflow's sidebar (Agent / Projects / Models / Deployments):
// related modules are clustered under a small uppercase group label instead
// of one flat list.
const NAV_GROUPS = [
  {
    label: 'Workspace',
    items: [
      { id: 'home', label: 'Home', Icon: Home },
      { id: 'chats', label: 'Chats', Icon: MessageCircle },
      { id: 'contacts', label: 'Contacts', Icon: Users },
      { id: 'pipelines', label: 'Pipelines', Icon: KanbanSquare },
    ],
  },
  {
    label: 'Automate',
    items: [
      { id: 'chatbot-builder', label: 'Automations', Icon: Zap },
      { id: 'template-builder', label: 'Template Builder', Icon: LayoutTemplate },
      { id: 'bulk-message', label: 'Bulk Message', Icon: Megaphone },
      { id: 'target-message', label: 'Target Message', Icon: Target },
    ],
  },
  {
    label: 'Library',
    items: [
      { id: 'media-library', label: 'Media', Icon: ImageIcon },
    ],
  },
];

export default function Sidebar({ activePage, onPageChange, collapsed, setCollapsed, user }) {
  const [hoveredId, setHoveredId] = useState(null);

  // Admins see every nav item; other roles see only the pages granted to them
  // (user.pages from the session). Falls back to all items if pages is missing.
  const canSee = (id) => user?.role === 'admin' || !Array.isArray(user?.pages) || user.pages.includes(id);

  return (
    <div style={{
      width: collapsed ? 64 : 232,
      minHeight: '100%',
      background: C.navBg,
      borderRight: `1px solid ${C.navBorder}`,
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      transition: 'width .2s ease',
      overflow: 'hidden',
      position: 'relative',
    }}>
      {/* Nav groups */}
      <div style={{ padding: collapsed ? '12px 8px' : '16px 12px', flex: 1, overflowY: 'auto' }}>
        {NAV_GROUPS.map((group, gi) => {
          const visible = group.items.filter(item => canSee(item.id));
          if (visible.length === 0) return null;
          return (
            <div key={group.label} style={{ marginBottom: gi < NAV_GROUPS.length - 1 ? 18 : 0 }}>
              {!collapsed && (
                <div style={{
                  fontSize: 10.5,
                  fontWeight: 700,
                  letterSpacing: '.08em',
                  textTransform: 'uppercase',
                  color: C.navMuted,
                  padding: '0 10px 6px',
                  fontFamily: FONT,
                }}>
                  {group.label}
                </div>
              )}
              {visible.map(item => {
                const active = activePage === item.id;
                const hovered = hoveredId === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => onPageChange(item.id)}
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    title={collapsed ? item.label : ''}
                    style={{
                      position: 'relative',
                      display: 'flex',
                      alignItems: 'center',
                      gap: collapsed ? 0 : 10,
                      padding: collapsed ? '10px 0' : '9px 10px',
                      borderRadius: C.radiusMd,
                      cursor: 'pointer',
                      marginBottom: 2,
                      background: active ? C.navActiveBg : (hovered ? C.navHover : 'transparent'),
                      color: active ? C.navActiveText : C.navMuted,
                      justifyContent: collapsed ? 'center' : 'flex-start',
                      fontFamily: FONT,
                      fontSize: 13,
                      fontWeight: active ? 600 : 500,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      userSelect: 'none',
                      transition: 'background .12s, color .12s',
                    }}
                  >
                    {active && (
                      <span style={{
                        position: 'absolute',
                        left: 0,
                        top: 6,
                        bottom: 6,
                        width: 3,
                        borderRadius: 3,
                        background: C.navActiveBar,
                      }} />
                    )}
                    <span style={{
                      width: 18,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flexShrink: 0,
                      color: active ? C.navActiveText : C.navMuted,
                    }}>
                      <item.Icon size={16} strokeWidth={active ? 2.25 : 2} />
                    </span>
                    {!collapsed && <span style={{ letterSpacing: '-.01em' }}>{item.label}</span>}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Collapse control + watermark */}
      <div style={{ borderTop: `1px solid ${C.navBorder}` }}>
        <div
          onClick={() => setCollapsed(p => !p)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: collapsed ? '12px 0' : '11px 12px',
            cursor: 'pointer',
            justifyContent: collapsed ? 'center' : 'flex-start',
            transition: 'background .12s',
            color: C.navMuted,
          }}
          onMouseEnter={e => e.currentTarget.style.background = C.navHover}
          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <span style={{
            width: 20, height: 20, borderRadius: 6,
            background: C.navHover,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            {collapsed ? <ChevronRight size={13} /> : <ChevronLeft size={13} />}
          </span>
          {!collapsed && (
            <span style={{ fontSize: 12, fontWeight: 600, fontFamily: FONT }}>
              Collapse
            </span>
          )}
        </div>
        <div style={{ padding: collapsed ? '0 0 10px' : '0 12px 12px', textAlign: collapsed ? 'center' : 'left' }}>
          <span style={{
            fontSize: collapsed ? 7 : 9,
            fontWeight: 700,
            color: 'rgba(255,255,255,.25)',
            fontFamily: FONT,
            letterSpacing: '.08em',
            textTransform: 'uppercase',
          }}>
            {collapsed ? 'AK' : 'Powered by AK'}
          </span>
        </div>
      </div>
    </div>
  );
}