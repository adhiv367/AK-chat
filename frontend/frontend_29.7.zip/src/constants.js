export const C = {
  pageBg: 'var(--c-pageBg, #F6F6F8)',
  sidebarBg: 'var(--c-sidebarBg, #101018)',
  sidebarBorder: 'var(--c-sidebarBorder, rgba(255,255,255,.08))',
  headerBg: 'var(--c-headerBg, #ffffff)',
  headerText: 'var(--c-headerText, #14141F)',
  headerMuted: 'var(--c-headerMuted, #8A8A9A)',
  headerBorder: 'var(--c-headerBorder, #E7E7ED)',
  headerSurface: 'var(--c-headerSurface, #F2F1F8)',
  cardBg: 'var(--c-cardBg, #ffffff)',
  border: 'var(--c-border, #E7E7ED)',
  borderDark: 'var(--c-borderDark, #D5D5E0)',
  text: 'var(--c-text, #14141F)',
  textSecondary: 'var(--c-textSecondary, #6B6B7B)',
  textMuted: 'var(--c-textMuted, #9494A3)',
  primary: 'var(--c-primary, #6D28D9)',
  primaryHover: 'var(--c-primaryHover, #5B21B6)',
  primaryLight: 'var(--c-primaryLight, #F1EBFD)',
  primaryText: 'var(--c-primaryText, #14141F)',
  purple: 'var(--c-purple, #6D28D9)',
  green: 'var(--c-green, #0F6E56)',
  amber: 'var(--c-amber, #B45309)',
  shadowSm: 'var(--c-shadowSm, 0 1px 2px rgba(16,16,24,.06))',
  shadowMd: 'var(--c-shadowMd, 0 8px 24px rgba(16,16,24,.08))',
  shadowLg: 'var(--c-shadowLg, 0 20px 60px rgba(16,16,24,.16))',
  waBg: 'var(--c-waBg, #e5ddd5)',
  surface: 'var(--c-surface, #ffffff)',
  surfaceAlt: 'var(--c-surfaceAlt, #F6F6F8)',
  hover: 'var(--c-hover, #F2F1F8)',
  waBgPattern: 'url("data:image/svg+xml,%3Csvg width=\'16\' height=\'16\' viewBox=\'0 0 16 16\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M0 0h8v8H0z\' fill=\'%23d1d7db\' fill-opacity=\'0.15\'/%3E%3C/svg%3E")',

  navBg: 'var(--c-navBg, #101018)',
  navBgAlt: 'var(--c-navBgAlt, #17171F)',
  navText: 'var(--c-navText, #F3F3F6)',
  navMuted: 'var(--c-navMuted, #9A9AAE)',
  navBorder: 'var(--c-navBorder, rgba(255,255,255,.08))',
  navHover: 'var(--c-navHover, rgba(255,255,255,.06))',
  navActiveBg: 'var(--c-navActiveBg, rgba(109,40,217,.28))',
  navActiveText: 'var(--c-navActiveText, #ffffff)',
  navActiveBar: 'var(--c-navActiveBar, #A78BFA)',
  radiusSm: 'var(--c-radiusSm, 6px)',
  radiusMd: 'var(--c-radiusMd, 10px)',
  radiusLg: 'var(--c-radiusLg, 14px)',
};


export const IG = {
  primary: '#E1306C',
  gradient: 'linear-gradient(135deg, #833AB4, #E1306C, #FCAF45)',
  sidebarBg: '#fafafa',
  accentBg: '#fdf2f8',
  border: '#f0d9e4',
  text: '#262626',
  textMuted: '#8e8e8e',
  cardBg: '#ffffff',
};

export const CHAT = {
  incomingBg: 'var(--c-incomingBg, #ffffff)',
  incomingText: 'var(--c-incomingText, #111b21)',
  outgoingBg: 'var(--c-outgoingBg, #d9fdd3)',
  outgoingText: 'var(--c-outgoingText, #111b21)',
  chatBg: 'var(--c-chatBg, #e5ddd5)',
  bubbleRadius: '7.5px',
  bubblePadding: '6px 7px 8px 9px',
  statusDelivered: 'var(--c-statusDelivered, #53bdeb)',
  statusRead: 'var(--c-statusRead, #53bdeb)',
  statusSent: 'var(--c-statusSent, #8696a0)',
};

export const FONT = "'DM Sans', system-ui, sans-serif";
export const MONO = "'DM Mono', monospace";

export function relativeTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const diff = Math.floor((now - d) / 1000);
  if (diff < 60) return 'now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

export function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
}

export function maskPhone(raw) {
  const s = String(raw ?? '');
  const digits = s.replace(/\D/g, '');
  if (digits.length <= 5) return s;
  return digits.slice(0, 2) + '*'.repeat(digits.length - 5) + digits.slice(-3);
}

export function darkenColor(hex, factor = 0.5) {
  const m = /^#?([0-9a-fA-F]{6})$/.exec(hex || '');
  if (!m) return '#374151';
  const n = parseInt(m[1], 16);
  const r = Math.round(((n >> 16) & 255) * factor);
  const g = Math.round(((n >> 8) & 255) * factor);
  const b = Math.round((n & 255) * factor);
  return `rgb(${r}, ${g}, ${b})`;
}

export function formatDate(ts) {
  const d = new Date(ts);
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  if (isToday) return 'Today';
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
}

